# COVID-19-Relief-Fund
Task 3 of  Web Development and Designing Intern at The Sparks Foundation
The task was to integrate a payment gateway in a simple website with a donate button on the home page. the donate button will lead to a payment page where user can select the amount to be paid. On successful payment an invoice will be generated and an email will be sent to the user confirming the payment received.
Techstack used - HTML,CSS,Javascript,Bootstrap
Payment Gateway - Razorpay
